import { Controller, Get, Param } from '@nestjs/common';
import { PlanetService } from './planets.service';

@Controller('planetas')
export class PlanetController {
  constructor(private readonly appService: PlanetService) {}

  @Get()
  getAll(): object {
    return this.appService.getPlanets();
  }

  @Get(':id')
  findOne(@Param('id') id: number) {
    return this.appService.getPlanetById(id);
  }
}
